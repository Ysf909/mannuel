enum OtpPurpose { signUp, resetPassword }
