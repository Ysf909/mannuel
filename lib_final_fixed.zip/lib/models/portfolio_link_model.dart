class PortfolioLink {
  final String title;
  final String url;

  const PortfolioLink({required this.title, required this.url});
}
