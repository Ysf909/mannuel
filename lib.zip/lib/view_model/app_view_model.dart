import 'package:flutter/material.dart';

class AppViewModel extends ChangeNotifier {
  // reserved for app-wide state later
}
